import subprocess,sys
from pathlib import Path
root=Path.cwd()
for attempt in range(3):
    with (root/f'.validation/ci39997143184/locker-bounded-{attempt}.log').open('wb') as log:
        code=subprocess.run([sys.executable,'scripts/run_tests_isolated.py','--',sys.executable,'-m','pytest','tests/test_user_locker_browser.py::test_locker_browser_http_mcp',f'--junitxml=.validation/ci39997143184/locker-bounded-{attempt}.xml','-q'],stdout=log,stderr=subprocess.STDOUT,timeout=150).returncode
    print('attempt',attempt,'exit',code,flush=True)
    if code:raise SystemExit(code)
