import time
from packages.jobs.independent_service import JobStore
from tempfile import TemporaryDirectory
from pathlib import Path
with TemporaryDirectory() as root:
 s=JobStore(root)
 t=time.monotonic()
 from packages.jobs.system_actions import prepare
 print('cold system_actions',time.monotonic()-t)
 t=time.monotonic()
 from packages.jobs.unified import project
 print('cold unified',time.monotonic()-t)
