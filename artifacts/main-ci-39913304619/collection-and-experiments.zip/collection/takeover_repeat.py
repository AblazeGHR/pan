from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
for i in range(10):
    code=subprocess.run([sys.executable,str(root/'scripts/run_tests_isolated.py'),'--',sys.executable,'-m','pytest',
        'tests/test_takeover_lifecycle_http.py::test_http_first_terminal_survives_real_reader_conflict_without_resend',
        '-q','--junitxml='+str(out/f'takeover-{i}.xml'),'--basetemp='+str(out/f'takeover-{i}-tmp')],cwd=root).returncode
    print('TAKEOVER_CASE',i,'EXIT',code,flush=True)
    if code:raise SystemExit(code)
