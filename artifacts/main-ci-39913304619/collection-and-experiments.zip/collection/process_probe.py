import asyncio
import json
from pathlib import Path
import sys
import tempfile
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.run_tests_isolated import test_environment
import os
os.environ.clear() if False else None
for k in tuple(os.environ):
    if k.upper().startswith('PAN_'):
        os.environ.pop(k)
import psutil
from tests.test_plugin_events import setup, session, manifest

async def main():
    results=[]
    for i in range(20):
        with tempfile.TemporaryDirectory(prefix='pan-ci-process-') as td:
            svc, manager, _=await setup(Path(td),{'a':session('a',['observer','producer'])},manifest())
            try:
                await manager.reconcile(); await manager.settle()
                c=manager.connections['observer']
                processes=[psutil.Process(c.process.pid),*psutil.Process(c.process.pid).children(recursive=True)]
                ids=[{'pid':p.pid,'created':p.create_time(),'command':p.cmdline()} for p in processes]
                c.reader.cancel()
                while c.cleanup is None: await asyncio.sleep(.001)
                await asyncio.wait_for(asyncio.shield(c.cleanup),.5)
                remaining=[]
                for p,identity in zip(processes,ids):
                    if psutil.pid_exists(p.pid):
                        try:
                            remaining.append({**identity,'status':p.status(),'same':p.create_time()==identity['created']})
                        except psutil.NoSuchProcess: pass
                results.append({'iteration':i,'captured':ids,'remainingAtCleanup':remaining})
                print(json.dumps(results[-1]),flush=True)
            finally:
                await manager.close();await svc.close()
    Path(__file__).with_name('process-probe.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    assert not any(r['remainingAtCleanup'] for r in results), 'Cleanup returned before owned descendants retired'

asyncio.run(main())
