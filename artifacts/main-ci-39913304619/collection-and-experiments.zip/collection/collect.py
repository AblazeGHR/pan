import json
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
GH = r'D:/Program Files/GitHub CLI/gh.exe'
import shutil
GH = shutil.which('gh') or GH
REPO = 'AblazeGHR/pan'
RUN = '39913304619'

def command(args, name, timeout=180, attempts=3):
    for attempt in range(attempts):
        out = ROOT / (name if attempt == 0 else f'{name}.attempt{attempt+1}')
        with out.open('wb') as stdout, Path(str(out)+'.stderr').open('wb') as stderr:
            try:
                result = subprocess.run([GH, *args], stdout=stdout, stderr=stderr, timeout=timeout)
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
        print(json.dumps({'file': str(out), 'exitcode': code}), flush=True)
        if code == 0:
            if attempt:
                (ROOT/name).write_bytes(out.read_bytes())
            return out
        if attempt+1 < attempts:
            time.sleep(15)
    raise RuntimeError(f'Collection failed: {name}')

command(['run','watch',RUN,'--repo',REPO,'--interval','60'], 'watch.log', timeout=7200, attempts=1)
run = command(['api',f'repos/{REPO}/actions/runs/{RUN}'], 'run.json')
metadata = json.loads(run.read_text('utf-8'))
assert metadata['head_sha'] == '0156f008b149d59641ccc0176721c8e2b5ae59d8'
assert metadata['status'] == 'completed'
jobs = command(['api',f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100'], 'jobs.json')
command(['api',f'repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100'], 'artifacts.json')
errors = []
for job in json.loads(jobs.read_text('utf-8'))['jobs']:
    try:
        command(['api',f'repos/{REPO}/actions/jobs/{job["id"]}/logs'], f'job-{job["id"]}.log')
    except Exception as exc:
        errors.append(str(exc))
try:
    command(['run','download',RUN,'--repo',REPO,'--dir',str(ROOT/'artifacts')], 'download.log', timeout=300)
except Exception as exc:
    errors.append(str(exc))
summary = []
for path in (ROOT/'artifacts').rglob('*.xml'):
    tree = ET.parse(path)
    cases = list(tree.iter('testcase'))
    failures = []
    skips = []
    for case in cases:
        for child in case:
            if child.tag in ('failure','error','skipped'):
                entry = {'classname':case.get('classname'),'name':case.get('name'),'type':child.tag,'message':child.get('message'),'text':child.text}
                (skips if child.tag == 'skipped' else failures).append(entry)
    summary.append({'file':str(path),'tests':len(cases),'failures':failures,'skips':skips})
(ROOT/'junit-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'summaries':[(s['file'],s['tests'],len(s['failures']),len(s['skips'])) for s in summary],'collection_errors':errors}),flush=True)
assert len(summary) == 2, 'Both matrix JUnit artifacts required'
assert not errors, errors
