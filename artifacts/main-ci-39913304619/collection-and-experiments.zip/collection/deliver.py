import collections
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

here=Path(__file__).resolve().parent
root=here.parents[1]
dest=root/'artifacts/main-ci-39913304619'
dest.mkdir(parents=True,exist_ok=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert source=='f36592ece507ff708f9b65a66bafff36b863dda5'
tree=ET.parse(here/'focused-green.xml')
suites=list(tree.iter('testsuite'))
assert len(suites)==1
suite=suites[0]
assert suite.get('tests')=='503' and suite.get('failures')=='0' and suite.get('errors')=='0' and suite.get('skipped')=='1'
cases={(c.get('classname'),c.get('name')):c for c in tree.iter('testcase')}
summary=json.loads((here/'junit-summary.json').read_text(encoding='utf-8'))
failures=sorted({(f['classname'],f['name']) for leg in summary for f in leg['failures']})
assert len(failures)==14
assert all(k in cases and not any(c.tag in ('failure','error','skipped') for c in cases[k]) for k in failures)
probe=json.loads((here/'process-probe.json').read_text(encoding='utf-8'))
assert len(probe)==20 and not any(p['remainingAtCleanup'] for p in probe)
remote=[]
identities=[]
for path in sorted((here/'artifacts').rglob('*.xml')):
    r=ET.parse(path)
    identities.append(collections.Counter((c.get('classname'),c.get('name')) for c in r.iter('testcase')))
    remote.append({'matrix':path.parent.name,'suite':list(r.iter('testsuite'))[0].attrib,
                   'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (dest/(path.parent.name+'.xml.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
assert len(identities)==2 and identities[0]==identities[1]
result={'sourceSha':source,'baseMainSha':'c277d76ab7dbdaffc5947984756290762cbf5166',
    'originalCiSha':'0156f008b149d59641ccc0176721c8e2b5ae59d8','run':39913304619,
    'localPython':'3.14.5','localExitCode':0,'finalJobId':'job_d9c99dc334726253abeffa0c',
    'suite':suite.attrib,'originalFailureIdentities':[{'classname':k[0],'name':k[1],'final':'passed'} for k in failures],
    'ownedTreeChecks':20,'ownedTreeChecksWithRemainingProcesses':0,'remote':remote,
    'remoteIdentityMultisetsMatch':True,'fullLocalMatrixRun':False,'candidateRemoteCiRun':False}
(dest/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['red.xml','focused-green.xml','cancellation-red.xml','uncertainty-green.xml','junit-summary.json']:
    shutil.copyfile(here/name,dest/name)
for name in ['job-120281026974.log','job-120281027493.log']:
    (dest/(name+'.gz')).write_bytes(gzip.compress((here/name).read_bytes(),mtime=0))
log_root=Path('D:/project/Pan/data/background_jobs/logs')
final_log=log_root/'job_d9c99dc334726253abeffa0c.log'
shutil.copyfile(final_log,dest/'final-job.log')
with zipfile.ZipFile(dest/'collection-and-experiments.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(here.iterdir()):
        if path.is_file() and path.suffix in {'.xml','.json','.py','.ps1','.txt','.log'} and path.name not in {'delivery-draft.md'}:
            z.write(path,'collection/'+path.name)
    z.write(here/'takeover-timeout-evidence.zip','takeover-timeout-evidence.zip')
    for job in ['job_0dd23a9ef01a078ab80e489c','job_d1e14b9b72c35406941a9ffe','job_36b04eaad3e3327a11a76b4a',
                'job_65bbd44ef1a4a97a30955c2a','job_e4b7c8e1121e03e37080b27c','job_43821f56619a3dbb35c539e3',
                'job_3ab7f9777b6fc50cfef71fbf','job_d76f0787d0e0813b40048096','job_d9222ff7306e37e46ef2836c',
                'job_d9c99dc334726253abeffa0c']:
        z.write(log_root/(job+'.log'),'jobs/'+job+'.log')
files=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
generated=[p for p in files if p.startswith(('artifacts/eta-final/','artifacts/job-unified-live/',
    'artifacts/retry-parallel/','artifacts/event-plugin-adapter/','audit/locker-runtime/http/'))]
assert len(files)==len(generated),files
with zipfile.ZipFile(dest/'owned-runtime-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in generated:z.write(root/name,name)
    z.write(here/'process-probe-red.json','process-probe-red.json')
    z.write(here/'process-probe.json','process-probe-green.json')
report=(here/'delivery-draft.md').read_text(encoding='utf-8')
report += '''

## 最终验收事实

- 精确源码 `f36592ece507ff708f9b65a66bafff36b863dda5`：503 项，**502 passed / 0 failed / 0 error / 1 既有 skip**，pytest 与持久 Job 均退出 0；耗时 273.880 秒。
- 两腿原始 JUnit 的 5507 个测试身份多重集一致；合并后的全部 14 个失败身份均在最终相关集中通过。
- 20 次自有树退出检查全部通过，cleanup 返回时未发现剩余已捕获进程。最终 Job Registry 同时记录 processTreeEnded=true。
- 最终相关集唯一 skip 为 gitignored 的本地 skill 同步副本不存在；未新增 skip/xfail。
- 编译语法检查、Node `--check` 和源码 `git diff --check` 退出 0。此前本树冻结依赖构建成功；本轮无前端产品源码改动，真实 Chromium 已在相关集中执行。

## 证据入口与复核

- `validation.json`：精确 SHA、双矩阵原始统计、全部 14 个失败身份的最终去向、退出码与覆盖声明。
- `red.xml` / `focused-green.xml`：原 SHA 本地红测与最终源码相关集绿测；原矩阵 JUnit 是 `pytest-results-3.12.xml.gz` / `pytest-results-3.14.xml.gz`。
- `job-120281027493.log.gz` / `job-120281026974.log.gz`：完整原矩阵日志；`final-job.log`：最终持久 Job 完整输出。
- `junit-summary.json`：原失败 traceback 与全部既有 skip 身份/原因。
- `collection-and-experiments.zip`：收集元数据/脚本、红绿及中间失败 JUnit、原 Job 日志、关机中断日志和单次 takeover 超时的自有 profile 证据；没有删除失败实验。
- `owned-runtime-evidence.zip`：本轮隔离 Chromium/HTTP 生成物以及进程退出诊断；其来源均为临时 profile，不是生产数据。
- `SHA256SUMS.json`：交付文件校验和。源码提交之后仅新增交付证据，不改源文件。

重做相关集可使用证据 ZIP 中的 `focused.py` 与 `process_probe.py`，放回本树 `.validation/ci39913304619/` 并保持 `junit-summary.json` 同目录，执行：

```powershell
& D:/project/Pan-main/.venv/Scripts/python.exe D:/project/pan-worktrees/main-ci-39913304619/.validation/ci39913304619/focused.py
```

长命令应由执行者自己的持久 Job 运行并接收终态；不要直接轮询工具。预期 pytest 503 项、502 passed / 1 skip，随后 20 次进程检查，最终退出 0。MA 仍需独立验收，候选远端双矩阵尚未运行。
'''
(dest/'DELIVERY.md').write_text(report,encoding='utf-8')
checks={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.is_file() and p.name!='SHA256SUMS.json'}
(dest/'SHA256SUMS.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
for path in dest.glob('*.zip'):
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
if generated:
    subprocess.run(['git','restore','--',*generated],cwd=root,check=True)
print(json.dumps({'source':source,'evidence':str(dest),'restoredGeneratedFiles':len(generated),'suite':suite.attrib},ensure_ascii=False))
