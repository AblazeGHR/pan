$ErrorActionPreference = 'Stop'
Set-Location D:/project/pan-worktrees/main-ci-39913304619
& D:/node_npm/node_global/pnpm.cmd --dir packages/web install --frozen-lockfile --store-dir D:/project/pan-worktrees/main-ci-39913304619/.validation/pnpm-store
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& D:/node_npm/node_global/pnpm.cmd --dir packages/web build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$ci = Get-Content .validation/ci39913304619/junit-summary.json -Raw | ConvertFrom-Json
$nodes = @($ci.failures | Sort-Object classname,name -Unique | ForEach-Object {
    $parts = $_.classname -split '\.'
    'tests/' + $parts[1] + '.py::' + $(if ($parts.Length -gt 2) { $parts[2] + '::' }) + $_.name
})
& D:/project/Pan-main/.venv/Scripts/python.exe scripts/run_tests_isolated.py -- D:/project/Pan-main/.venv/Scripts/python.exe -m pytest @nodes -q -ra --junitxml=.validation/ci39913304619/red.xml --basetemp=.validation/ci39913304619/red-tmp
exit $LASTEXITCODE
