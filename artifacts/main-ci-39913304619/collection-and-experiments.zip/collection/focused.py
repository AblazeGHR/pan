import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
nodes={'tests/'+f['classname'].split('.')[1]+'.py' for leg in json.loads((out/'junit-summary.json').read_text(encoding='utf-8')) for f in leg['failures']}
nodes.update('tests/'+n+'.py' for n in ['test_job_system_actions','test_job_cleanup_failures','test_job_unified_contract',
    'test_job_action_templates','test_job_overlap','test_job_completion_recovery','test_job_inbox_migration_drill',
    'test_queue_unknown_migration','test_self_queue','test_illegal_queue_wake','test_locker_trusted_binding',
    'test_interaction_cards','test_interaction_card_api','test_user_locker_lifecycle','test_pan_cli',
    'test_action_groups','test_automation_retry_parallel','test_plugin_events','test_queue_restart_hardening'])
code=subprocess.run([sys.executable,str(root/'scripts/run_tests_isolated.py'),'--',sys.executable,'-m','pytest',
    *sorted(nodes),'-q','-ra','--junitxml='+str(out/'focused-green.xml'),'--basetemp='+str(out/'focused-tmp')],cwd=root).returncode
print('FOCUSED_EXIT',code,flush=True)
if code==0:
    code=subprocess.run([sys.executable,str(out/'process_probe.py')],cwd=root).returncode
    print('PROCESS_PROBE_EXIT',code,flush=True)
raise SystemExit(code)
