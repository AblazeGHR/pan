from pathlib import Path
import subprocess
import zipfile
root=Path(__file__).resolve().parents[2]
files=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
generated=[p for p in files if p.startswith(('artifacts/eta-final/','artifacts/job-unified-live/','artifacts/retry-parallel/','audit/locker-runtime/http/'))]
if generated:
    with zipfile.ZipFile(Path(__file__).with_name('generated-before-final.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for p in generated:z.write(root/p,p)
    subprocess.run(['git','restore','--',*generated],cwd=root,check=True)
print('Preserved and restored',len(generated),'owned generated outputs')
