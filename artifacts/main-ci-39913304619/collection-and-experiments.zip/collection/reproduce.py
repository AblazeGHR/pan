import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
folder = Path(__file__).resolve().parent
label = sys.argv[1] if len(sys.argv) > 1 else 'red'
nodes = set()
for leg in json.loads((folder/'junit-summary.json').read_text(encoding='utf-8')):
    for failure in leg['failures']:
        parts = failure['classname'].split('.')
        nodes.add('tests/'+parts[1]+'.py::'+'::'.join(parts[2:]+[failure['name']]))
raise SystemExit(subprocess.run([sys.executable,str(root/'scripts/run_tests_isolated.py'),'--',sys.executable,
    '-m','pytest',*sorted(nodes),'-q','-ra','--junitxml='+str(folder/(label+'.xml')),'--basetemp='+str(folder/(label+'-tmp'))],cwd=root).returncode)
