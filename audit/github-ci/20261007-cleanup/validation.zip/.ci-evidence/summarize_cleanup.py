import collections,hashlib,json,pathlib,xml.etree.ElementTree as E
r=pathlib.Path('.ci-evidence')
ids=json.loads((r/'collection.json').read_text())
lookup={}
for node in ids:
 parts=node.split('::'); classname=parts[0][:-3].replace('/','.')
 if len(parts)>2:classname+='.'+'.'.join(parts[1:-1])
 key=(classname,parts[-1]);assert key not in lookup;lookup[key]=node
original=json.loads((r/'original-classification.json').read_text())
summary={}
for version in ('312','314'):
 execution=json.loads((r/f'cleanup-final{version}-execution.json').read_text())
 assert execution['exit_code']==0,execution
 root=E.parse(r/f'cleanup-final{version}.xml').getroot()
 cases=root.findall('.//testcase'); outcomes={};skips=[]
 for case in cases:
  node=lookup[(case.attrib['classname'],case.attrib['name'])]
  state='failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
  assert node not in outcomes;outcomes[node]=state
  if state=='skipped':skips.append({'test':node,'reason':case.find('skipped').attrib.get('message','')})
 assert collections.Counter(outcomes.keys())==collections.Counter(ids)
 assert all(v not in ('failed','error') for v in outcomes.values())
 prior=json.loads((r/f'run-37450384323-py{version}-outcomes.json').read_text())
 original_failures=[{'test':x['test'],'outcome':outcomes[x['test']]} for x in prior if x['outcome']=='F']
 assert all(x['outcome']=='passed' for x in original_failures)
 summary[version]={'counts':dict(collections.Counter(outcomes.values())),'collected':len(cases),'suite':root.find('testsuite').attrib,'execution':execution,'skips':skips,'original_failures':original_failures,'original_skips':[{'test':x['test'],'outcome':outcomes[x['test']]} for x in prior if x['outcome']=='s']}
expected=json.loads((r/'candidate-source-hashes.json').read_text())
assert all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==v for p,v in expected.items())
production=json.loads((r/'production-repeat-results.json').read_text());assert len(production)==6 and all(x['exit_code']==0 for x in production)
summary['production_repeats']=production
(r/'cleanup-final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
for version in ('312','314'):
 print(version,summary[version]['counts'],summary[version]['suite']['time'])
 print(summary[version]['skips'])
print('All original failure identities pass; final suites exactly preserve all original tests plus nine regressions.')




