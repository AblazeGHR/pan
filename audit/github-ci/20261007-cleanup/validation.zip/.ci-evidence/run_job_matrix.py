from __future__ import annotations
import datetime, hashlib, json, os, pathlib, subprocess, sys, tempfile

repo = pathlib.Path(__file__).resolve().parents[1]
evidence = repo / '.ci-evidence'
sys.path.insert(0, str(repo / 'scripts'))
from run_tests_isolated import test_environment

hashes = json.loads((evidence / 'candidate-source-hashes.json').read_text())
for path in ('packages/core/terminal/launcher.py', 'tests/test_terminal_launcher.py'):
    hashes[path] = ''
hashes = {path: hashlib.sha256((repo / path).read_bytes()).hexdigest() for path in hashes}
(evidence / 'candidate-source-hashes.json').write_text(json.dumps(hashes, indent=2))
collected = subprocess.run([str(repo / '.venv-ci314/Scripts/python.exe'), '-m', 'pytest', 'tests/', 'packages/qq', '--collect-only', '-q', '-o', 'addopts='], cwd=repo, capture_output=True, text=True, encoding='utf-8', env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
assert collected.returncode == 0, collected.stderr
ids = [line.strip() for line in collected.stdout.splitlines() if '::' in line and not line.startswith(' ')]
assert len(ids) == 2916, len(ids)
(evidence / 'collection.json').write_text(json.dumps(ids, indent=2))

def run(version, label, tests):
    root = pathlib.Path(tempfile.gettempdir()) / f'pan-ci-20261006-job-{version}-{label}'
    profile = root / 'profile'
    for path in (profile, profile / 'AppData/Roaming', profile / 'AppData/Local', root / 'tmp'):
        path.mkdir(parents=True, exist_ok=True)
    env = test_environment(dict(os.environ), repo)
    env.update(USERPROFILE=str(profile), APPDATA=str(profile / 'AppData/Roaming'), LOCALAPPDATA=str(profile / 'AppData/Local'), TEMP=str(root / 'tmp'), TMP=str(root / 'tmp'), PYTHONIOENCODING='utf-8')
    args = [str(repo / f'.venv-ci{version}/Scripts/python.exe'), '-m', 'pytest', *tests, '-o', 'addopts=', '-o', 'junit_family=legacy', '-v', '-ra', f'--basetemp={root}/pytest', f'--junitxml={evidence}/{label}{version}.xml']
    record = dict(command=args, cwd=str(repo), home=str(profile), tmp=str(root / 'tmp'), http_port=env['PAN_TEST_HTTP_PORT'], started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    print(f'START {label} Python {version}', flush=True)
    with (evidence / f'{label}{version}.log').open('w', encoding='utf-8') as log:
        log.write(json.dumps(record) + '\n'); log.flush()
        result = subprocess.run(args, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode, completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (evidence / f'{label}{version}-execution.json').write_text(json.dumps(record, indent=2))
    print(f'END {label} Python {version}: {result.returncode}', flush=True)
    return result.returncode

failed = False
for version in ('312', '314'):
    failed |= bool(run(version, 'job-launcher', ['tests/test_terminal_launcher.py']))
    failed |= bool(run(version, 'job-final', ['tests/', 'packages/qq']))
assert all(hashlib.sha256((repo / path).read_bytes()).hexdigest() == value for path, value in hashes.items())
raise SystemExit(int(failed))
