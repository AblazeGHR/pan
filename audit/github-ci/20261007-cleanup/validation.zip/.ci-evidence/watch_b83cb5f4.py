import json,pathlib,subprocess,time
repo=pathlib.Path(__file__).resolve().parents[1]
sha='b83cb5f4b3c328206dbb58a42cfaccbc2d73ed5d'
out=repo/'.ci-evidence/remote-b83cb5f4'
out.mkdir(exist_ok=True)
for attempt in range(1,7):
 print(f'Exact SHA lookup attempt {attempt}',flush=True)
 try:
  result=subprocess.run(['gh','run','list','--repo','AblazeGHR/pan','--commit',sha,'--json','databaseId,url,headSha,status,conclusion,workflowName','--limit','20'],capture_output=True,text=True,encoding='utf-8',timeout=60)
 except subprocess.TimeoutExpired:
  print('GitHub lookup command timeout',flush=True)
 else:
  if result.returncode==0:
   runs=[x for x in json.loads(result.stdout) if x['workflowName']=='tests' and x['headSha']==sha]
   if runs:
    run=runs[0]
    (out/'selected-run.json').write_text(json.dumps(run,indent=2),encoding='utf-8')
    print(json.dumps(run),flush=True)
    raise SystemExit(subprocess.call(['gh','run','watch',str(run['databaseId']),'--repo','AblazeGHR/pan','--exit-status','--interval','30']))
  print(result.stderr or 'No exact SHA tests run found yet',flush=True)
 if attempt<6:time.sleep(20)
raise SystemExit(2)
