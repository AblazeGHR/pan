# Exact-SHA remote acceptance: FAILED

Run: https://github.com/AblazeGHR/pan/actions/runs/37461154308
headSha: `ee2816b61691be8bc185ba2a264999b09100120e`
Pan watch Job: `job_38ee213d2d98393cf39ca33e`, failed exitCode 1, notification delivered.

Both jobs completed with failure: Python 3.12 job 112260762729 and Python 3.14 job 112260762485. Each JUnit contains all 2916 expected test identities: 2897 passed, 17 skipped, 2 failed, no errors. Both dependency installation and JUnit upload steps succeeded. All original 40 failure identities per leg now pass. Both current failures were dependency-skipped in original run 37450384323.

Failures, identical on both legs:

1. `tests/test_terminal_archive_scope_ma.py::test_real_external_kill_is_exited_and_archivable`: identity-bound kill succeeds and retained spawn handle reports exited; subsequent service.get reports `running`, expected `exited` with cleanup_pending True. Full assertion and trace are in each raw log and JUnit.
2. `tests/test_terminal_durable_ma.py::test_detached_shell_survives_real_service_host_exit_and_reconnect`: child host returns 1; captured traceback ends in `CleanupUnconfirmed: engine-cleanup-unproven`. Failure cleanup subsequently calls service.close and raises `TerminalNotAttached: not-attached`, which is the final reported failure. The child's full stderr is truncated by pytest assertion rendering; no unprinted root cause is inferred. This is not the supported skip branch (host exit 23).

Checks passed on both legs:

- Cooperative Ctrl-C JUnit property: `ctrl_c_observation=keyboard-interrupt`; real production foreground Ctrl-C also passes.
- 120k summary backfill test passes its unchanged `max(gaps) < 0.05` assertion; measured maximum gap is not emitted, so no precise latency number is claimed.
- Secret concurrent writes/identity updates, publication mutex/error preservation regression and launcher stale-snapshot accounting regression pass.

All 17 skips per leg were checked: Claude CLI unavailable (1), absent Claude machine probes (7), missing gitignored checkout CodeBuddy skill copy (1), absent Kimi machine probes (3), frontend reconciliation probes missing esbuild (3), timezone database absent (1), actual ancestor-Job detach restriction (1). Some non-ASCII JUnit reasons contain replacement characters; raw logs and test source distinguish those two categories. No remaining sidecar dependency skip.

Evidence: complete run archive `run-logs.zip` (CRC checked), standalone full job logs `py312.log`/`py314.log`, both downloaded original JUnit XML files under `artifacts/`, run metadata, watch Registry/log, per-test summary with complete failure text and SHA256 manifest. No code, main, push, tag/release, service or user-profile action was performed during this acceptance.

These observations establish remote failures, not their implementation/test/environment root cause. MA should authorize any subsequent repair separately; current work remains read-only.
