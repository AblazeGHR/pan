import collections, hashlib, json, pathlib, xml.etree.ElementTree as E, zipfile
r=pathlib.Path(__file__).resolve().parent
summary={}
expected=json.loads((r.parents[1]/'audit/github-ci/20261006/collection.json').read_text())
lookup={}
for node in expected:
 parts=node.split('::'); key=(parts[0][:-3].replace('/','.')+('.'+'.'.join(parts[1:-1]) if len(parts)>2 else ''),parts[-1]);lookup[key]=node
for version in ('3.12','3.14'):
 root=E.parse(r/f'artifacts/pytest-results-{version}/pytest-results.xml').getroot()
 cases=root.findall('.//testcase');outcomes={};failures=[];skips=[];checks=[]
 for case in cases:
  node=lookup[(case.attrib['classname'],case.attrib['name'])]
  fail=case.find('failure'); error=case.find('error');skip=case.find('skipped')
  outcome='failed' if fail is not None else 'error' if error is not None else 'skipped' if skip is not None else 'passed'
  outcomes[node]=outcome
  if fail is not None or error is not None:
   evidence=fail if fail is not None else error
   failures.append({'test':node,'message':evidence.attrib.get('message'),'trace':evidence.text})
  if skip is not None:skips.append({'test':node,'reason':skip.attrib.get('message')})
  if any(word in node for word in ('ctrl_c','120k_summary','concurrent_writes','publication_mutex','exit_between_snapshot')):
   checks.append({'test':node,'outcome':outcome,'time':case.attrib.get('time'),'properties':[p.attrib for p in case.findall('./properties/property')]})
 assert collections.Counter(outcomes)==collections.Counter({node:outcomes[node] for node in expected})
 assert set(outcomes)==set(expected)
 original=json.loads((r.parents[1]/f'audit/github-ci/20261006/run-37450384323-py{version.replace(".","")}-outcomes.json').read_text())
 prior_failures=[{'test':x['test'],'outcome':outcomes[x['test']]} for x in original if x['outcome']=='F']
 assert len(prior_failures)==40 and all(x['outcome']=='passed' for x in prior_failures)
 assert all(next(x['outcome'] for x in original if x['test']==f['test'])=='s' for f in failures)
 summary[version]={'suite':root.find('testsuite').attrib,'counts':dict(collections.Counter(outcomes.values())),'failures':failures,'skips':skips,'checks':checks,'original_40_failures':prior_failures,'new_failures_originally_skipped':True}
with zipfile.ZipFile(r/'run-logs.zip') as archive:
 assert archive.testzip() is None
 summary['archive']={'members':len(archive.namelist()),'crc':'pass'}
(r/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(r/'manifest.json').write_text(json.dumps({str(p.relative_to(r)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in r.rglob('*') if p.is_file() and p.name!='manifest.json'},indent=2),encoding='utf-8')
for v in ('3.12','3.14'):
 print(v,summary[v]['counts']);print(json.dumps(summary[v]['checks'],ensure_ascii=False));print(json.dumps(summary[v]['skips'],ensure_ascii=False))
