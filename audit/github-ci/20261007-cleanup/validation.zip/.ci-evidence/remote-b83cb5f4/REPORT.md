# Exact candidate remote acceptance: one remaining test cleanup failure

Run https://github.com/AblazeGHR/pan/actions/runs/37503444960
headSha `b83cb5f4b3c328206dbb58a42cfaccbc2d73ed5d`.
Both jobs completed failure: Python 3.12 job 112405992336; Python 3.14 job 112405992744. Pan Job `job_bc53ee9fe9729b6881190bdd` failed exitCode 1 because watch observed remote failure, not because the initial transient API connection issue persisted.

Each original JUnit contains the exact 2918 candidate test identities: 2900 passed, 17 skipped, one failed, zero errors. All original 40 failing identities pass per leg. Dependency installs and JUnit artifact uploads succeed.

External identity-bound kill/archive test now PASSES on both legs. Both new service regressions pass. Ctrl-C tests including real foreground interrupt pass; cooperative observation is `keyboard-interrupt` on both. 120k summary projection backfill passes unchanged max(gaps) < 0.05; actual maximum gap is not printed. Secret concurrency and read-error preservation pass.

Remaining failure on both legs: `tests/test_terminal_durable_ma.py::test_detached_shell_survives_real_service_host_exit_and_reconnect`. The full traceback explicitly shows host.returncode == 23 followed by pytest.skip at line 96: actual ancestor Job disallows breakaway; detach safely refused. During handling, finally line 131 calls service.close; `_require_state` raises `TerminalNotAttached: not-attached`. `tid` had already been assigned before skip, so the test's conditional `if tid is None and report_path.exists(): service.reconcile()` does not execute. The parent service never attached/reconciled this terminal. This is a test cleanup bug masking an existing supported environment skip, not a durable detach success. Do not claim missing engine cleanup still occurs: the child completed its close sufficiently to return 23 in this run.

All 17 current skips per leg match previous candidate categories and identities: Claude CLI/probes 8, Kimi probes 3, frontend missing esbuild 3, checkout skill sync copy 1, timezone data 1, same-service ancestor-Job detach restriction 1. Remaining failed cross-host test has an existing skip path that is currently masked; no new skip has been added.

Evidence beside this report: complete CRC-verified run-logs.zip, full py312.log/py314.log, downloaded original artifacts/pytest-results-3.12 and 3.14 XML, run metadata, watch Registry/log, per-test summary including all failure text and skip reasons, SHA256 manifest. Acceptance only: no code changes/commits, main/push, tag/release, services, practical or user-profile operation. Shutdown remains deferred per MA's latest instruction.
