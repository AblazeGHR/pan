import hashlib,json,pathlib,shutil,zipfile
repo=pathlib.Path(__file__).resolve().parents[1]
scratch=repo/'.ci-evidence'
target=repo/'audit/github-ci/20261007'
for label in ('job_7fce74b12d9ec81967ceb63d','job_66856681c766effea1196a54','job_535fd9aeffa1f75afbee5dff'):
 shutil.copyfile(pathlib.Path('D:/project/Pan/data/background_jobs/logs')/(label+'.log'),scratch/(label+'.log'))
for file in ('remaining-final-summary.json','candidate-source-hashes.json','remaining-final312.xml','remaining-final314.xml','remaining-parent-proof.log'):
 shutil.copyfile(scratch/file,target/file)
with zipfile.ZipFile(target/'validation.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(scratch.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(repo)))
with zipfile.ZipFile(target/'validation.zip') as z:assert z.testzip() is None
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in target.iterdir() if p.is_file() and p.name!='manifest.json'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Evidence archive CRC verified')
