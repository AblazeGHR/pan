from __future__ import annotations
import datetime,json,os,pathlib,subprocess,sys,tempfile
repo=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(repo/'scripts'))
from run_tests_isolated import test_environment
version=sys.argv[1]
root=pathlib.Path(tempfile.gettempdir())/f'pan-ci-20261006-isolated-{version}'
profile=root/'profile'
for p in (profile,profile/'AppData/Roaming',profile/'AppData/Local',root/'tmp'):
 p.mkdir(parents=True,exist_ok=True)
env=test_environment(dict(os.environ),repo)
env.update(USERPROFILE=str(profile),APPDATA=str(profile/'AppData/Roaming'),LOCALAPPDATA=str(profile/'AppData/Local'),TEMP=str(root/'tmp'),TMP=str(root/'tmp'))
python=repo/f'.venv-ci{version}/Scripts/python.exe'
args=[str(python),'-m','pytest','tests/','packages/qq','-o','addopts=','-o','junit_family=legacy','-v','-ra',f'--basetemp={root}/pytest',f'--junitxml={repo}/.ci-evidence/isolated-final{version}.xml']
record={'command':args,'cwd':str(repo),'home':str(profile),'tmp':str(root/'tmp'),'http_port':env['PAN_TEST_HTTP_PORT'],'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (repo/f'.ci-evidence/isolated-final{version}.log').open('w',encoding='utf-8') as log:
 log.write(json.dumps(record,ensure_ascii=False)+'\n');log.flush()
 result=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(repo/f'.ci-evidence/isolated-final{version}-execution.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
raise SystemExit(result.returncode)
