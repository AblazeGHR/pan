import ast, subprocess, types, pytest
from packages.core.terminal import service
source=subprocess.check_output(['git','show','ee2816b61691be8bc185ba2a264999b09100120e:packages/core/terminal/service.py']).decode('utf-8')
owner=next(node for node in ast.parse(source).body if isinstance(node,ast.ClassDef) and node.name=='TerminalService')
for name in ('_start_terminal','_close_state'):
 method=next(node for node in owner.body if isinstance(node,ast.FunctionDef) and node.name==name)
 namespace=dict(service.__dict__)
 exec(compile(ast.Module(body=[method],type_ignores=[]),'<remote-parent-service>','exec'),namespace)
 setattr(service.TerminalService,name,types.FunctionType(namespace[name].__code__,service.__dict__))
raise SystemExit(pytest.main(['tests/test_terminal_service.py::test_direct_launcher_retains_runner_handle_without_python_shim','tests/test_terminal_service.py::test_close_waits_for_late_engine_and_exit_proofs_without_resending','-q','-o','addopts=','--basetemp=C:/Users/14709/AppData/Local/Temp/pan-remaining-parent-proof']))
