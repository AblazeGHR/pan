import ast,subprocess,types,pytest,sys
import tests.test_terminal_durable_ma as suite
source=subprocess.check_output(['git','show','b83cb5f4b3c328206dbb58a42cfaccbc2d73ed5d:tests/test_terminal_durable_ma.py']).decode('utf-8')
name='test_detached_shell_survives_real_service_host_exit_and_reconnect'
method=next(node for node in ast.parse(source).body if isinstance(node,ast.FunctionDef) and node.name==name)
namespace=dict(suite.__dict__)
exec(compile(ast.Module(body=[method],type_ignores=[]),'<exact-parent-durable-test>','exec'),namespace)
setattr(suite,name,types.FunctionType(namespace[name].__code__,suite.__dict__))
sys.modules['test_terminal_durable_ma']=suite
raise SystemExit(pytest.main(['tests/test_terminal_durable_ma.py::test_refused_host_skip_requires_verified_cleanup_and_releases_resources','-q','-o','addopts=','--basetemp=C:/Users/14709/AppData/Local/Temp/pan-cleanup-parent-proof']))
