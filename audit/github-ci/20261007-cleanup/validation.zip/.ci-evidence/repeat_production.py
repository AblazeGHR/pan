import os,pathlib,subprocess,sys,tempfile,json
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'scripts'))
from run_tests_isolated import test_environment
root=pathlib.Path(tempfile.gettempdir())/'pan-ci-20261006-production-repeat'
profile=root/'profile'
for p in (profile,profile/'AppData/Roaming',profile/'AppData/Local',root/'tmp'):p.mkdir(parents=True,exist_ok=True)
env=test_environment(dict(os.environ),repo)
env.update(USERPROFILE=str(profile),APPDATA=str(profile/'AppData/Roaming'),LOCALAPPDATA=str(profile/'AppData/Local'),TEMP=str(root/'tmp'),TMP=str(root/'tmp'),PYTHONIOENCODING='utf-8')
results=[]
for version in ('312','314'):
 python=str(repo/f'.venv-ci{version}/Scripts/python.exe')
 with (repo/f'.ci-evidence/production-repeat{version}.log').open('w',encoding='utf-8') as log:
  for i in range(3):
   log.write(f'ROUND {i+1}\n');log.flush()
   rc=subprocess.run([python,'-m','pytest','tests/test_terminal_interrupt_ma.py::test_real_production_ctrl_c_interrupts_foreground_and_preserves_shell','-o','addopts=','-q',f'--basetemp={root}/pytest{version}-{i}',f'--junitxml={repo}/.ci-evidence/production-repeat{version}-{i}.xml'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
   log.write(f'EXIT {rc}\n');log.flush();results.append({'python':version,'round':i+1,'exit_code':rc})
   if rc:break
(repo/'.ci-evidence/production-repeat-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
raise SystemExit(any(x['exit_code'] for x in results))
