import ast, subprocess, pytest
from packages.core.terminal import launcher
source = subprocess.check_output(['git', 'show', '9f1108a940cf3a0cc514724ad23ccd83daf99de4:packages/core/terminal/launcher.py']).decode('utf-8')
tree = ast.parse(source)
owner = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'TerminalLauncher')
method = next(node for node in owner.body if isinstance(node, ast.FunctionDef) and node.name == '_finalize_engine')
namespace = dict(launcher.__dict__)
exec(compile(ast.Module(body=[method], type_ignores=[]), '<baseline-finalize-engine>', 'exec'), namespace)
# Keep the real module namespace so the test's worker injection applies.
import types
launcher.TerminalLauncher._finalize_engine = types.FunctionType(namespace['_finalize_engine'].__code__, launcher.__dict__)
raise SystemExit(pytest.main(['tests/test_terminal_launcher.py::test_engine_close_exit_between_snapshot_and_invoke_counts_retry', '-q', '-o', 'addopts=', '--basetemp=C:/Users/14709/AppData/Local/Temp/pan-ci-launcher-parent-proof']))
