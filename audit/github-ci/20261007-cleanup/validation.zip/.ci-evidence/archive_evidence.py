import hashlib, json, pathlib, shutil, zipfile
repo = pathlib.Path(__file__).resolve().parents[1]
source = repo / '.ci-evidence'
target = repo / 'audit/github-ci/20261006'
files = ['run-37450384323-logs.zip', 'run-37450384323-py312.log', 'run-37450384323-py314.log', 'raw-log-manifest.json', 'original-classification.json', 'run-37450384323-py312-outcomes.json', 'run-37450384323-py314-outcomes.json', 'final-summary.json', 'candidate-source-hashes.json', 'collection.json', 'job-final312.xml', 'job-final314.xml', 'job-final312.log', 'job-final314.log', 'job-final312-execution.json', 'job-final314-execution.json', 'pan-job-matrix.log']
for name in files:
    shutil.copyfile(source / name, target / name)
archive = target / 'local-validation.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as output:
    for path in sorted(source.rglob('*')):
        if path.is_file():
            output.write(path, str(path.relative_to(repo)))
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
manifest = {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in target.iterdir() if path.is_file() and path.name != 'evidence-manifest.json'}
(target / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('Archived', len(manifest), 'files; validation archive CRC verified')
