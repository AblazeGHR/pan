import json,pathlib,pytest,sys
class Manifest:
 def pytest_collection_finish(self,session):
  pathlib.Path('.ci-evidence/collection.json').write_text(json.dumps([i.nodeid for i in session.items],indent=2),encoding='utf-8')
raise SystemExit(pytest.main(['tests/','packages/qq','--collect-only','-q'],plugins=[Manifest()]))
