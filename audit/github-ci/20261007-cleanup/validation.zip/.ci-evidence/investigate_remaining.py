import datetime,json,os,pathlib,subprocess,sys,tempfile
repo=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(repo/'scripts'))
from run_tests_isolated import test_environment
out=repo/'.ci-evidence/remaining-investigation'
out.mkdir(exist_ok=True)
results=[]
for version in ('312','314'):
 for round in range(1,6):
  root=pathlib.Path(tempfile.gettempdir())/f'pan-ci-remaining-{version}-{round}'
  profile=root/'profile'
  for path in (profile,profile/'AppData/Roaming',profile/'AppData/Local',root/'tmp'):path.mkdir(parents=True,exist_ok=True)
  env=test_environment(dict(os.environ),repo)
  env.update(USERPROFILE=str(profile),APPDATA=str(profile/'AppData/Roaming'),LOCALAPPDATA=str(profile/'AppData/Local'),TEMP=str(root/'tmp'),TMP=str(root/'tmp'),PYTHONIOENCODING='utf-8')
  args=[str(repo/f'.venv-ci{version}/Scripts/python.exe'),'-m','pytest','tests/test_terminal_archive_scope_ma.py::test_real_external_kill_is_exited_and_archivable','tests/test_terminal_durable_ma.py','-o','addopts=','-vv','-ra','--tb=long','--showlocals',f'--basetemp={root}/pytest',f'--junitxml={out}/{version}-{round}.xml']
  with (out/f'{version}-{round}.log').open('w',encoding='utf-8') as log:
   result=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  record={'python':version,'round':round,'exit_code':result.returncode,'argv':args,'home':str(profile),'port':env['PAN_TEST_HTTP_PORT']}
  results.append(record)
  (out/'results.json').write_text(json.dumps(results,indent=2))
  print(json.dumps(record),flush=True)
raise SystemExit(int(any(x['exit_code'] for x in results)))
