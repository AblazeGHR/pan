import hashlib,json,pathlib,shutil,zipfile
repo=pathlib.Path(__file__).resolve().parents[1]
scratch=repo/'.ci-evidence'
target=repo/'audit/github-ci/20261007-cleanup'
for job in ('job_6963835dd1318c8e067ca138','job_51c442a2036755c5b2b866ca'):
 shutil.copyfile(pathlib.Path('D:/project/Pan/data/background_jobs/logs')/(job+'.log'),scratch/(job+'.log'))
for name in ('cleanup-final-summary.json','candidate-source-hashes.json','cleanup-final312.xml','cleanup-final314.xml','cleanup-parent-proof.log','collection.json'):
 shutil.copyfile(scratch/name,target/name)
with zipfile.ZipFile(target/'validation.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(scratch.rglob('*')):
  if path.is_file():archive.write(path,str(path.relative_to(repo)))
assert zipfile.ZipFile(target/'validation.zip').testzip() is None
manifest={path.name:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in target.iterdir() if path.is_file() and path.name!='manifest.json'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
hashes=json.loads((target/'candidate-source-hashes.json').read_text())
assert all(hashlib.sha256((repo/path).read_bytes()).hexdigest()==value for path,value in hashes.items())
print('Evidence CRC and candidate source hashes pass')
