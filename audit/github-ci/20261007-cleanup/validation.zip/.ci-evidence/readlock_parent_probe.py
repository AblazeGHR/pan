import ast,subprocess,pytest,sys
class ParentRead:
 def pytest_sessionstart(self,session):
  from packages.core.terminal import secret_store
  source=subprocess.check_output(['git','show','9f1108a940cf3a0cc514724ad23ccd83daf99de4:packages/core/terminal/secret_store.py']).decode('utf-8')
  cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='SecretStore')
  method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='read_secret')
  scope=dict(vars(secret_store))
  exec(compile(ast.Module(body=[method],type_ignores=[]),'<baseline read_secret>','exec'),scope)
  secret_store.SecretStore.read_secret=scope['read_secret']
raise SystemExit(pytest.main(sys.argv[1:],plugins=[ParentRead()]))
