import asyncio,sys,pytest
real_run=asyncio.run
async def watch():
 await asyncio.sleep(20)
 print('ASYNC TASK DUMP',file=sys.stderr,flush=True)
 for task in asyncio.all_tasks():
  print(repr(task),file=sys.stderr,flush=True)
  task.print_stack(file=sys.stderr)
def debug_run(coro,**kw):
 async def wrapped():
  watcher=asyncio.create_task(watch())
  try: return await coro
  finally:
   watcher.cancel()
   await asyncio.gather(watcher,return_exceptions=True)
 return real_run(wrapped(),**kw)
asyncio.run=debug_run
raise SystemExit(pytest.main(sys.argv[1:]))
